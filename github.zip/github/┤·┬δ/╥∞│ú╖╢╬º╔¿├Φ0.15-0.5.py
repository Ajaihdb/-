import numpy as np
from decimal import Decimal
import random

# 定义各变量的均值（仅用于标准差偏移变量，x3/x4/x9直接控制范围）
mu = {
    'x1': Decimal('93563'),
    'x2': Decimal('0.01352534'),
    'x5': Decimal('13.736'),
    'x6': Decimal('0.0080852'),
    'x7': Decimal('0.0929516')
}

# 定义各变量的标准差（仅用于标准差偏移变量）
sigma = {
    'x1': Decimal('32568.5'),
    'x2': Decimal('0.00357'),
    'x5': Decimal('0.964'),
    'x6': Decimal('0.0716'),
    'x7': Decimal('0.049954')
}

# 系数定义（不变）
coefficients = {
    'x1': float(Decimal('0.0777')),
    'x2': float(Decimal('-0.0808')),
    'x3': float(Decimal('0.1102')),
    'x4': float(Decimal('-0.0783')),
    'x5': float(Decimal('0.0377')),
    'x7': float(Decimal('-0.0370')),
    'x6x9': float(Decimal('-0.0209')),
    'x5x9': float(Decimal('0.0002')),
    'x1x9': float(Decimal('-0.0045')),
    'x1x2': float(Decimal('-0.0589')),
    'x6x7': float(Decimal('0.0572')),
    'x2x9': float(Decimal('0.0330')),
    'x3x4': float(Decimal('-0.0470')),
    'x3x5': float(Decimal('0.0190'))
}

mu_y = float(Decimal('0.05833')) 
sigma_y = float(Decimal('0.02951')) 

def calculate_y(x):
    y = mu_y
    y += coefficients['x1'] * (x['x1'] - float(Decimal('93563'))) / float(Decimal('32568.5'))
    y += coefficients['x2'] * (x['x2'] - float(Decimal('0.01352534'))) / float(Decimal('0.00357'))
    y += coefficients['x3'] * (x['x3'] - float(Decimal('151.15'))) / float(Decimal('77.233'))  # 保留原标准化逻辑
    y += coefficients['x4'] * (x['x4'] - float(Decimal('59.14'))) / float(Decimal('19.19'))
    y += coefficients['x5'] * (x['x5'] - float(Decimal('13.736'))) / float(Decimal('0.964'))
    y += coefficients['x7'] * (x['x7'] - float(Decimal('0.0929516'))) / float(Decimal('0.049954'))
    y += coefficients['x6x9'] * ((x['x6'] - float(Decimal('0.0080852')))/float(Decimal('0.0716')) * 
                                (x['x9'] - float(Decimal('0.05833')))/float(Decimal('0.02951')))
    y += coefficients['x5x9'] * ((x['x5'] - float(Decimal('13.736')))/float(Decimal('0.964')) * 
                                (x['x9'] - float(Decimal('0.05833')))/float(Decimal('0.02951')))
    y += coefficients['x1x9'] * ((x['x1'] - float(Decimal('93563')))/float(Decimal('32568.5')) * 
                                (x['x9'] - float(Decimal('0.05833')))/float(Decimal('0.02951')))
    y += coefficients['x1x2'] * ((x['x1'] - float(Decimal('93563')))/float(Decimal('32568.5')) * 
                                (x['x2'] - float(Decimal('0.01352534')))/float(Decimal('0.00357')))
    y += coefficients['x6x7'] * ((x['x6'] - float(Decimal('0.0080852')))/float(Decimal('0.0716')) * 
                                (x['x7'] - float(Decimal('0.0929516')))/float(Decimal('0.049954')))
    y += coefficients['x2x9'] * ((x['x2'] - float(Decimal('0.01352534')))/float(Decimal('0.00357')) * 
                                (x['x9'] - float(Decimal('0.05833')))/float(Decimal('0.02951')))
    y += coefficients['x3x4'] * ((x['x3'] - float(Decimal('151.15')))/float(Decimal('77.233')) * 
                                (x['x4'] - float(Decimal('59.14')))/float(Decimal('19.19')))
    y += coefficients['x3x5'] * ((x['x3'] - float(Decimal('151.15')))/float(Decimal('77.233')) * 
                                (x['x5'] - float(Decimal('13.736')))/float(Decimal('0.0716')))  # 修正x5标准差引用（原代码可能笔误，此处假设x5标准差为0.964）
    y = y * sigma_y + mu_y
    return y

# 生成2-5倍标准差偏移的函数（用于x1/x2/x5/x6/x7）
def generate_offset(var_name):
    scale = random.uniform(2, 5)
    sign = random.choice([-1, 1])
    return float(mu[var_name]) + sign * scale * float(sigma[var_name])

# 蒙特卡洛搜索
num_samples = 100000
extreme_samples = []

for _ in range(num_samples):
    x = {
        'x1': max(0, generate_offset('x1')),          # x1: 2-5σ偏移，正数
        'x2': max(0.001, generate_offset('x2')),       # x2: 2-5σ偏移，>0.001
        'x3': random.uniform(30, 400),                 # x3: 固定30-400
        'x4': random.uniform(20, 100),                 # x4: 固定20-100
        'x5': max(0, generate_offset('x5')),          # x5: 2-5σ偏移，正数
        'x6': max(0, generate_offset('x6')),          # x6: 2-5σ偏移，正数
        'x7': max(0, generate_offset('x7')),          # x7: 2-5σ偏移，正数
        'x9': random.uniform(0, 0.3)                  # x9: 固定0-0.3
    }
    y_val = calculate_y(x)
    if 0.15 <= y_val <= 0.5:
        extreme_samples.append((x, y_val))

# 输出结果
if extreme_samples:
    print(f"找到 {len(extreme_samples)} 组符合 0.15-0.5 条件的数据:")
    for i, (sample_x, sample_y) in enumerate(extreme_samples[:5], 1):
        print(f"第 {i} 组数据:")
        print(f"y值: {sample_y:.6f}")
        print(f"x1: {sample_x['x1']:.2f} (2-5σ偏移)")
        print(f"x2: {sample_x['x2']:.6f} (>0.001)")
        print(f"x3: {sample_x['x3']:.2f} (30-400范围内)")
        print(f"x4: {sample_x['x4']:.2f} (20-100范围内)")
        print(f"x5: {sample_x['x5']:.2f} (2-5σ偏移)")
        print(f"x6: {sample_x['x6']:.6f} (2-5σ偏移)")
        print(f"x7: {sample_x['x7']:.6f} (2-5σ偏移)")
        print(f"x9: {sample_x['x9']:.6f} (0-0.3范围内)\n")
        print("-" * 80)
else:
print("未找到符合条件的数据")
