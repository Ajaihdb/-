import re
from decimal import Decimal, getcontext

# 设置高精度计算，这里设置为50位精度
getcontext().prec = 50

# 定义各变量的均值
mu = {
    'x1': Decimal('93563'),
    'x2': Decimal('0.01352534'),
    'x3': Decimal('151.15'),
    'x4': Decimal('59.14'),
    'x5': Decimal('13.736'),
    'x6': Decimal('0.0080852'),
    'x7': Decimal('0.0929516'),
    'x9': Decimal('0.05833')
}

# 定义各变量的标准差
sigma = {
    'x1': Decimal('32568.5'),
    'x2': Decimal('0.00357'),
    'x3': Decimal('77.233'),
    'x4': Decimal('19.19'),
    'x5': Decimal('0.096'),
    'x6': Decimal('0.091'),
    'x7': Decimal('0.049954'),
    'x9': Decimal('0.02951')
}

mu_y = Decimal('0.05833')  # 因变量均值
sigma_y = Decimal('0.02951')  # 因变量标准差

# 根据新标准化尺度下公式修改系数定义
coefficients = {
    'x1': Decimal('0.0777'),
    'x2': Decimal('-0.0808'),
    'x3': Decimal('0.1102'),
    'x4': Decimal('-0.0783'),
    'x5': Decimal('0.0377'),
    'x7': Decimal('-0.0370'),  # 一次项x7
    'x6x9': Decimal('-0.0209'),
    'x5x9': Decimal('0.0002'),
    'x1x9': Decimal('-0.0045'),
    'x1x2': Decimal('-0.0589'),
    'x6x7': Decimal('0.0572'),
    'x2x9': Decimal('0.0330'),
    'x3x4': Decimal('-0.0470'),
    'x3x5': Decimal('0.0190')
}

# 输出常数项
print(f"常数项: {mu_y}")

# 计算并输出一次项系数
linear_coeffs = {}
# 一次项变量列表，增加x7
linear_vars = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7']
for j_var in linear_vars:
    beta_j = coefficients.get(j_var, Decimal('0'))
    term1 = beta_j * sigma_y / sigma[j_var]
    adjustment = Decimal('0')
    # 找所有 i < j 的交互项
    for interact_var, beta_ij in coefficients.items():
        match = re.match(r'^(x\d+)(x\d+)$', interact_var)
        if match:
            i_var, j_var_interact = match.groups()
            # 确保 i < j，这里通过变量顺序判断，假设变量名中的数字是标识
            i_num = int(i_var[1:])
            j_num = int(j_var[1:])
            if j_var_interact == j_var and i_num < j_num:
                mu_i = mu[i_var]
                sigma_i = sigma[i_var]
                sigma_j = sigma[j_var]
                adjustment += beta_ij * mu_i / (sigma_i * sigma_j)
    term2 = sigma_y * adjustment
    final_coeff = term1 - term2
    linear_coeffs[j_var] = final_coeff
    print(f"{j_var} 的系数: {final_coeff}")

# 计算并输出交互项系数
interaction_coeffs = {}
for interact_var, beta_ij in coefficients.items():
    match = re.match(r'^(x\d+)(x\d+)$', interact_var)
    if match:
        i_var, j_var = match.groups()
        i_num = int(i_var[1:])
        j_num = int(j_var[1:])
        if i_num < j_num:  # 确保 i < j
            sigma_i = sigma[i_var]
            sigma_j = sigma[j_var]
            term = beta_ij * sigma_y / (sigma_i * sigma_j)
            interaction_coeffs[interact_var] = term
            print(f"{interact_var} 的系数: {term}")

# 将高精度计算结果转换为浮点数系数
coefficients_float = {
    'constant': float(mu_y),
    **{k: float(v) for k, v in linear_coeffs.items()},
    **{k: float(v) for k, v in interaction_coeffs.items()}
}

# 给定的原始 x 值
x_values = {
    'x1': 144736,
    'x2': 0.017,
    'x3': 51.11,
    'x4': 30,
    'x5': 13.73,
    'x6': 0.001465862,
    'x7': 0.065,
    'x9': 0.059228
}

# 计算各项贡献
interaction_contributions = {}
for interact_var, coeff in coefficients_float.items():
    # 仅处理键名形如 'xixj' 的交互项（i,j 为数字）
    match = re.match(r'x(\d+)x(\d+)', interact_var)
    if match:
        var1 = f'x{match.group(1)}'  # 生成 'x2' 格式
        var2 = f'x{match.group(2)}'  # 生成 'x9' 格式
        # 检查变量是否存在于 x_values 中
        if var1 in x_values and var2 in x_values:
            interaction_contributions[interact_var] = coeff * x_values[var1] * x_values[var2]

# 合并所有贡献（常数项、一次项、交互项）
total_y = coefficients_float['constant']
# 一次项贡献（键名为 'x1', 'x2' 等）
for var, coeff in coefficients_float.items():
    if var.startswith('x') and not re.search(r'x\d+x\d+', var):  # 排除交互项，仅一次项
        if var in x_values:
            total_y += coeff * x_values[var]
# 交互项贡献（已筛选）
total_y += sum(interaction_contributions.values())

print(f"计算得到的 y 值为: {total_y:.10f}")