import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.regression.linear_model import GLSAR
import statsmodels.api as sm
from sklearn.ensemble import IsolationForest
from pathlib import Path

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False

# 标准化参数
MEAN = 0.05833
STD = 0.02951

# 读取数据
file_path = Path(r"C:\Users\小鑫\Desktop\数据导出.xlsx")
df = pd.read_excel(file_path)
df.sort_values(by="time", inplace=True)

# ================
# 数据预处理
# ================
print("正在进行数据预处理...")

# 构建自变量列表（已经处于标准化尺度下）
X_vars = ['e_new', 'mbishu_interp', 'mamiyue_interp', 'mjiage_interp', 
          'mvixyue_interp', 'mtps_interp', 'd_mshizhiXy_interpL1', 'd_mtvl', 
          'mtps_interpXy_interpL1', 'd_mshizhiXmvixyue_interp', 
          'mbishu_interpXy_interpL1', 'mamiyue_interpXmbishu_interp', 
          'mtps_interpXmvixyue_interp', 'd_mshizhiXd_mtvl', 
          'mamiyue_interpXy_interpL1', 'mjiage_interpXmvixyue_interp', 
          'mjiage_interpXmtps_interp']

# 检查并处理缺失值和无穷大值
def preprocess_data(df, columns):
    """处理数据中的缺失值和无穷大值"""
    processed_df = df.copy()
    
    # 检查并处理无穷大值
    for col in columns:
        if processed_df[col].dtype in [np.float64, np.int64]:
            processed_df[col] = processed_df[col].replace([np.inf, -np.inf], np.nan)
    
    # 插值填充缺失值
    processed_df.interpolate(method='linear', inplace=True)
    
    # 向前和向后填充剩余的缺失值
    processed_df.ffill(inplace=True)  # 替代fillna(method='ffill')
    processed_df.bfill(inplace=True)  # 替代fillna(method='bfill')
    
    return processed_df

# 预处理自变量和因变量
all_columns = X_vars + ['y_interp', 'huanshoujiduan']
df = preprocess_data(df, all_columns)

# 检查处理后的数据是否还有缺失值或无穷大值
print("数据预处理完成。检查数据质量：")
for col in all_columns:
    if df[col].isna().any():
        print(f"警告：列 {col} 仍然包含缺失值")
    if np.isinf(df[col]).any():
        print(f"警告：列 {col} 仍然包含无穷大值")

# ================
# 第一部分：两次Prais-Winsten回归模型
# ================
print("正在运行两次连续的Prais-Winsten回归模型...")

# 执行第一次Prais-Winsten回归（无截距项）
y_prais = df['y_interp']  # 使用原始因变量（假设已标准化）
X_prais = df[X_vars]  # 不添加常数项

# 第一次Prais-Winsten回归
model1 = GLSAR(y_prais, X_prais, rho=1)  # 假设AR(1)过程
results1 = model1.iterative_fit(maxiter=100)  # 迭代拟合直到收敛

# 计算第一次回归的残差
residuals1 = y_prais - results1.fittedvalues

# 将残差添加到数据框
df['residuals1'] = residuals1

# 创建残差的滞后一期变量
df['residuals1_lag1'] = df['residuals1'].shift(1)

# 处理滞后产生的缺失值
df['residuals1_lag1'] = df['residuals1_lag1'].fillna(method='bfill')

# 执行第二次Prais-Winsten回归（使用原始自变量+第一次残差的滞后项）
X_prais_with_resid_lag1 = X_prais.copy()
X_prais_with_resid_lag1['residuals1_lag1'] = df['residuals1_lag1']

# 第二次Prais-Winsten回归
model2 = GLSAR(y_prais, X_prais_with_resid_lag1, rho=1)  # 假设AR(1)过程
results2 = model2.iterative_fit(maxiter=100)  # 迭代拟合直到收敛

# 使用第二次回归的结果
yhat_prais_std = results2.fittedvalues  # 标准化尺度的预测值

# 逆标准化：将预测值和因变量转回原始尺度
def inverse_standardize(data, mean=MEAN, std=STD):
    """将标准化数据转回原始尺度"""
    return data * std + mean

yhat_prais = inverse_standardize(yhat_prais_std)  # 转回原始尺度
y_interp_original = inverse_standardize(df['y_interp'])  # 转回原始尺度的因变量

# 固定阈值异常检测（在原始尺度上）
lower_bound = 0.02
upper_bound = 0.2
alarm_prais = ((yhat_prais < lower_bound) | (yhat_prais > upper_bound)).astype(int)

# 将结果添加到原始数据（保留所有行，包括有缺失值的行）
df['yhat_prais'] = yhat_prais
df['alarm_prais'] = alarm_prais
df['y_interp_original'] = y_interp_original

# ================
# 第二部分：滑动窗口孤立森林模型（更新以避免FutureWarning）
# ================
print("正在运行1.5标准差严格版孤立森林模型...")

# 创建增强版滑动窗口特征函数（更新以避免FutureWarning）
def create_enhanced_sliding_features(df, column, window_size=5):
    """生成增强版滑动窗口特征，专注于波动检测"""
    result = df.copy()
    
    # 添加5期滞后值特征
    for i in range(1, window_size+1):
        result[f'{column}_lag{i}'] = result[column].shift(i)
    
    # 添加滚动统计特征（窗口大小=5）
    result[f'{column}_rolling_mean'] = result[column].rolling(window_size).mean()
    result[f'{column}_rolling_std'] = result[column].rolling(window_size).std()
    
    # 计算Z-score（关键特征：与均值的标准差距离）
    # 显式处理NaN值，避免FutureWarning
    rolling_mean = result[f'{column}_rolling_mean']
    rolling_std = result[f'{column}_rolling_std'].fillna(1e-8)  # 避免除零
    result[f'{column}_z_score'] = (result[column] - rolling_mean) / rolling_std
    
    # 添加短期/长期标准差比率（捕捉波动变化）
    result[f'{column}_rolling_std_short'] = result[column].rolling(window_size//2).std()
    result[f'{column}_rolling_std_long'] = result[column].rolling(window_size).std()
    result[f'{column}_std_ratio'] = result[f'{column}_rolling_std_short'] / \
                                    (result[f'{column}_rolling_std_long'].fillna(1e-8))
    
    # 添加变化率特征（绝对值增强敏感度）
    # 显式处理NaN值，避免FutureWarning
    pct_change = result[column].pct_change(fill_method=None)
    result[f'{column}_pct_change'] = pct_change.abs().fillna(0)
    
    # 填充缺失值 - 使用显式的ffill()和bfill()方法
    result.interpolate(method='linear', inplace=True)
    result.ffill(inplace=True)
    result.bfill(inplace=True)
    
    return result

# 生成时间窗口特征（使用前5个时间点）
window_size = 5
df_window = create_enhanced_sliding_features(df, 'huanshoujiduan', window_size)

# 构建孤立森林输入特征（专注于波动和标准差特征）
feature_columns = [
    'huanshoujiduan_rolling_mean',
    'huanshoujiduan_rolling_std',
    'huanshoujiduan_z_score',       # 关键特征：Z-score（与均值的标准差距离）
    'huanshoujiduan_std_ratio',     # 短期/长期标准差比率
    'huanshoujiduan_pct_change',    # 变化率
]

# 处理缺失值
X = df_window[feature_columns].values

# 使用前80%数据训练模型（假设前80%为正常数据）
train_size = int(len(X) * 0.8)
X_train = X[:train_size]

# 训练严格版孤立森林模型
iso_forest = IsolationForest(
    n_estimators=150,                # 增加树的数量提高精度
    contamination=0.08,              # 略微提高污染率
    random_state=42,
    max_features=0.8,                # 随机选择特征提高泛化能力
    bootstrap=True                   # 使用自助采样
)
iso_forest.fit(X_train)

# 获取异常分数（值越小越异常）
anomaly_scores = iso_forest.decision_function(X)

# 关键修改：将Z-score阈值设置为1.5个标准差
threshold = -0.1  # 基于经验的异常分数阈值，可根据实际情况调整
df_window['alarm_iso'] = ((df_window['huanshoujiduan_z_score'].abs() > 1.5) | 
                         (anomaly_scores < threshold)).astype(int)

# ================
# 合并结果并可视化（保持不变）
# ================
print("正在合并结果并生成可视化...")

# 合并两个模型的结果（保留所有行）
merged_df = pd.merge(df, df_window[['time', 'alarm_iso', 'huanshoujiduan_z_score']], on='time', how='left')
merged_df['alarm_iso'] = merged_df['alarm_iso'].fillna(0).astype(int)

# 合并报警信号
merged_df['combined_alarm'] = np.logical_or(merged_df['alarm_prais'], merged_df['alarm_iso']).astype(int)
merged_df['alarm_type'] = 0
merged_df.loc[(merged_df['alarm_prais'] == 1) & (merged_df['alarm_iso'] == 0), 'alarm_type'] = 1  # Prais检测到异常
merged_df.loc[(merged_df['alarm_prais'] == 0) & (merged_df['alarm_iso'] == 1), 'alarm_type'] = 2  # 孤立森林检测到异常
merged_df.loc[(merged_df['alarm_prais'] == 1) & (merged_df['alarm_iso'] == 1), 'alarm_type'] = 3  # 两者都检测到异常

# 可视化
plt.figure(figsize=(16, 8))
plt.plot(merged_df["time"], merged_df["huanshoujiduan"], 'b-', linewidth=1.5, label="原始数据 (huanshoujiduan)")
plt.plot(merged_df["time"], merged_df["yhat_prais"], 'g--', linewidth=2, label="Prais-Winsten预测 (原始尺度)")
plt.plot(merged_df["time"], merged_df["y_interp_original"], 'm-', linewidth=1, alpha=0.5, label="原始因变量 (y_interp)")
plt.axhline(y=lower_bound, color='black', linestyle='--', linewidth=1.5, alpha=0.7, label="固定阈值下限")
plt.axhline(y=upper_bound, color='black', linestyle='--', linewidth=1.5, alpha=0.7, label="固定阈值上限")

# 标记孤立森林检测到的异常点
anomaly_points = merged_df[merged_df["alarm_iso"] == 1]
plt.scatter(anomaly_points["time"], anomaly_points["huanshoujiduan"], 
            color='red', marker='o', s=100, facecolors='none', label="孤立森林检测到的异常")

plt.title("异常检测结果对比（1.5个标准差阈值）")
plt.xlabel("时间")
plt.ylabel("值")
plt.legend(loc='upper left', frameon=True, framealpha=0.9)
plt.grid(True, linestyle='--', alpha=0.7)

# 自适应y轴范围
# 确保计算y_min和y_max时不会出现NaN
if merged_df["yhat_prais"].notna().any():
    y_min = min(merged_df["huanshoujiduan"].min(), merged_df["yhat_prais"].min(), lower_bound) - 0.05
    y_max = max(merged_df["huanshoujiduan"].max(), merged_df["yhat_prais"].max(), upper_bound) + 0.05
else:
    y_min = merged_df["huanshoujiduan"].min() - 0.05
    y_max = merged_df["huanshoujiduan"].max() + 0.05

plt.ylim(y_min, y_max)

# 保存图片并显示
try:
    plt.savefig("异常检测结果.png", dpi=300, bbox_inches='tight')
    print("图表已成功保存")
except Exception as e:
    print(f"保存图表时出错: {e}")
    print("尝试使用备用字体设置...")
    # 尝试使用备用字体设置
    plt.rcParams["font.family"] = ["SimHei", "sans-serif"]
    try:
        plt.savefig("异常检测结果_备用.png", dpi=300, bbox_inches='tight')
        print("图表已使用备用字体成功保存")
    except Exception as e2:
        print(f"使用备用字体仍无法保存图表: {e2}")

plt.show()

# 保存结果到新Excel文件
output_path = Path(r"C:\Users\小鑫\Desktop\数据导出_异常标记.xlsx")
merged_df.to_excel(output_path, index=False)
print(f"结果已保存至: {output_path}")
print(f"孤立森林检测到 {merged_df['alarm_iso'].sum()} 个异常点")
print(f"Prais-Winsten模型检测到 {merged_df['alarm_prais'].sum()} 个异常点")