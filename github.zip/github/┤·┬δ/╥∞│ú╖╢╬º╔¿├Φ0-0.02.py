import numpy as np
from decimal import Decimal
import random

# 定义各变量的均值（保留原始定义，用于标准化计算）
mu = {
    'x1': Decimal('93563'),
    'x2': Decimal('0.01352534'),
    'x3': Decimal('151.15'),
    'x4': Decimal('59.14'),
    'x5': Decimal('13.736'),
    'x6': Decimal('0.0080852'),
    'x7': Decimal('0.0929516'),
    'x9': Decimal('0.05833')
}

# 定义各变量的标准差（保留原始定义，用于标准化计算）
sigma = {
    'x1': Decimal('32568.5'),
    'x2': Decimal('0.00357'),
    'x3': Decimal('77.233'),
    'x4': Decimal('19.19'),
    'x5': Decimal('0.964'),
    'x6': Decimal('0.0716'),
    'x7': Decimal('0.049954'),
    'x9': Decimal('0.02951')
}

# 模型系数（与原始定义一致，未修改）
coefficients = {
    'x1': float(Decimal('0.0777')),
    'x2': float(Decimal('-0.0808')),
    'x3': float(Decimal('0.1102')),
    'x4': float(Decimal('-0.0783')),
    'x5': float(Decimal('0.0377')),
    'x7': float(Decimal('-0.0370')),
    'x6x9': float(Decimal('-0.0209')),
    'x5x9': float(Decimal('0.0002')),
    'x1x9': float(Decimal('-0.0045')),
    'x1x2': float(Decimal('-0.0589')),
    'x6x7': float(Decimal('0.0572')),
    'x2x9': float(Decimal('0.0330')),
    'x3x4': float(Decimal('-0.0470')),
    'x3x5': float(Decimal('0.0190'))
}

mu_y = float(Decimal('0.05833'))  # y的均值
sigma_y = float(Decimal('0.02951'))  # y的标准差

def calculate_y(x):
    """计算y值的函数，使用标准化公式和交互项"""
    y = mu_y
    # 线性项和交互项的累加计算（基于标准化后的变量）
    y += coefficients['x1'] * (x['x1'] - float(mu['x1'])) / float(sigma['x1'])
    y += coefficients['x2'] * (x['x2'] - float(mu['x2'])) / float(sigma['x2'])
    y += coefficients['x3'] * (x['x3'] - float(mu['x3'])) / float(sigma['x3'])
    y += coefficients['x4'] * (x['x4'] - float(mu['x4'])) / float(sigma['x4'])
    y += coefficients['x5'] * (x['x5'] - float(mu['x5'])) / float(sigma['x5'])
    y += coefficients['x7'] * (x['x7'] - float(mu['x7'])) / float(sigma['x7'])
    y += coefficients['x6x9'] * ((x['x6'] - float(mu['x6']))/float(sigma['x6'])) * ((x['x9'] - float(mu['x9']))/float(sigma['x9']))
    y += coefficients['x5x9'] * ((x['x5'] - float(mu['x5']))/float(sigma['x5'])) * ((x['x9'] - float(mu['x9']))/float(sigma['x9']))
    y += coefficients['x1x9'] * ((x['x1'] - float(mu['x1']))/float(sigma['x1'])) * ((x['x9'] - float(mu['x9']))/float(sigma['x9']))
    y += coefficients['x1x2'] * ((x['x1'] - float(mu['x1']))/float(sigma['x1'])) * ((x['x2'] - float(mu['x2']))/float(sigma['x2']))
    y += coefficients['x6x7'] * ((x['x6'] - float(mu['x6']))/float(sigma['x6'])) * ((x['x7'] - float(mu['x7']))/float(sigma['x7']))
    y += coefficients['x2x9'] * ((x['x2'] - float(mu['x2']))/float(sigma['x2'])) * ((x['x9'] - float(mu['x9']))/float(sigma['x9']))
    y += coefficients['x3x4'] * ((x['x3'] - float(mu['x3']))/float(sigma['x3'])) * ((x['x4'] - float(mu['x4']))/float(sigma['x4']))
    y += coefficients['x3x5'] * ((x['x3'] - float(mu['x3']))/float(sigma['x3'])) * ((x['x5'] - float(mu['x5']))/float(sigma['x5']))
    y = y * sigma_y + mu_y  # 反标准化得到最终y值
    return y

# 蒙特卡洛搜索（调整后的变量范围和约束）
num_samples = 100000
extreme_samples = []

for _ in range(num_samples):
    x = {
        # x1: 在-4到5倍标准差范围内波动，确保正数
        'x1': max(0, float(mu['x1']) + random.uniform(-4, 5) * float(sigma['x1'])),  
        # x2: 在-4到5倍标准差范围内波动，确保正数
        'x2': max(0, float(mu['x2']) + random.uniform(-4, 5) * float(sigma['x2'])),  
        # x3: 固定范围5-100（用户显式约束）
        'x3': random.uniform(5, 100),  
        # x4: 固定范围20-100（用户显式约束）
        'x4': random.uniform(20, 100),  
        # x5: 在-4到5倍标准差范围内波动，确保正数
        'x5': max(0, float(mu['x5']) + random.uniform(-4, 5) * float(sigma['x5'])),  
        # x6: 在-4到5倍标准差范围内波动，确保正数
        'x6': max(0, float(mu['x6']) + random.uniform(-4, 5) * float(sigma['x6'])),  
        # x7: 在-5到5倍标准差范围内波动，且强制大于0.03（避免接近0）
        'x7': max(0.03, float(mu['x7']) + random.uniform(-5, 5) * float(sigma['x7'])),  
        # x9: 固定范围0.02-0.07（用户显式约束）
        'x9': random.uniform(0.02, 0.07)  
    }
    y_val = calculate_y(x)
    # 目标区间调整为0-0.02（较之前更严格）
    if 0 <= y_val <= 0.02:  
        extreme_samples.append((x, y_val))

# 输出结果（反映最新的约束和目标区间）
if extreme_samples:
    print(f"找到 {len(extreme_samples)} 组符合条件的数据（x7 > 0.03，y=0-0.02）:")
    for i, (sample_x, sample_y) in enumerate(extreme_samples[:5], 1):
        print(f"第 {i} 组:")
        print(f"y值: {sample_y:.8f}")
        print(f"x7: {sample_x['x7']:.6f} (>0.03，符合要求)")
        print(f"x1: {sample_x['x1']:.2f} | x3: {sample_x['x3']:.2f} | x9: {sample_x['x9']:.6f}")
        print(f"x2: {sample_x['x2']:.6f} | x4: {sample_x['x4']:.2f} | x5: {sample_x['x5']:.2f} | x6: {sample_x['x6']:.6f}")
        print("-" * 80)
else:
    print("未找到符合条件的数据，建议：\n1. 增大采样次数至1,000,000次\n2. 放宽x7的下限（如0.01）\n3. 结合系数分析，侧重x7正向偏移（x7系数为负，增大x7可降低y值）")