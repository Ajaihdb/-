import pandas as pd
import numpy as np
from decimal import Decimal
import tkinter as tk
from tkinter import ttk, messagebox

# 正常范围阈值
LOWER_BOUND = Decimal('0.02')
UPPER_BOUND = Decimal('0.2')

# 变量映射关系（输入变量名 -> 模型变量名）
INPUT_TO_MODEL = {
    'mbishu_interp': 'x1',       # 转账笔数（x1）
    'mamiyue_interp': 'x2',       # Amihud指标（x2）
    'mjiage_interp': 'x3',        # 价格波动（x3）
    'mvixyue_interp': 'x4',       # VIX恐慌指数（x4）
    'mtps_interp': 'x5',         # Tps（x5）
    'd_mshizhi': 'x6',           # △市值倒数（x6）
    'd_mtvl': 'x7',              # △tvl（x7）
    'y_interpL1': 'x9'           # 因变量滞后值（x9）
}

# 变量均值（mu）和标准差（sigma）
mu = {
    'x1': Decimal('93563'),
    'x2': Decimal('0.01352534'),
    'x3': Decimal('151.15'),
    'x4': Decimal('59.14'),
    'x5': Decimal('13.736'),
    'x6': Decimal('0.0080852'),
    'x7': Decimal('0.0929516'),
    'x9': Decimal('0.05833')     # 因变量滞后值均值
}

sigma = {
    'x1': Decimal('32568.5'),
    'x2': Decimal('0.00357'),     # 修正原代码中的标准差错误（原0.000357 -> 0.00357）
    'x3': Decimal('77.233'),
    'x4': Decimal('19.19'),
    'x5': Decimal('0.096'),       # 注意：原代码注释中的mtps_interp标准差可能有误，此处按用户定义
    'x6': Decimal('0.091'),
    'x7': Decimal('0.049954'),
    'x9': Decimal('0.02951')      # 因变量滞后值标准差
}

# 模型系数（包含一次项和交互项）
coefficients = {
    'x1': Decimal('0.0777'),
    'x2': Decimal('-0.0808'),
    'x3': Decimal('0.1102'),
    'x4': Decimal('-0.0783'),
    'x5': Decimal('0.0377'),
    'x7': Decimal('-0.0370'),    # x7一次项
    'x6x9': Decimal('-0.0209'),   # x6与x9的交互项（d_mshizhi * y_interpL1）
    'x5x9': Decimal('0.0002'),    # x5与x9的交互项
    'x1x9': Decimal('-0.0045'),   # x1与x9的交互项
    'x1x2': Decimal('-0.0589'),   # x1与x2的交互项
    'x6x7': Decimal('0.0572'),    # x6与x7的交互项
    'x2x9': Decimal('0.0330'),    # x2与x9的交互项
    'x3x4': Decimal('-0.0470'),   # x3与x4的交互项
    'x3x5': Decimal('0.0190')     # x3与x5的交互项
}

# 因变量均值和标准差（用于结果还原）
mu_y = Decimal('0.05833')
sigma_y = Decimal('0.02951')

# 修正系数（根据您的反馈添加）
CORRECTION_FACTOR = Decimal('0.73')

# 变量描述信息（用于界面显示）
variable_desc = {
    'mbishu_interp': '转账笔数',
    'mamiyue_interp': 'Amihud指标',
    'mjiage_interp': '价格波动',
    'mvixyue_interp': 'VIX恐慌指数',
    'mtps_interp': 'Tps',
    'd_mshizhi': '△市值倒数',
    'd_mtvl': '△tvl',
    'y_interpL1': '因变量滞后值'
}

# 标准化输入值并计算模型变量
def standardize_input(input_values):
    std_input = {}
    for input_var, model_var in INPUT_TO_MODEL.items():
        if input_var not in input_values:
            raise ValueError(f"缺少必要输入变量：{input_var}")
        value = Decimal(input_values[input_var])
        std_value = (value - mu[model_var]) / sigma[model_var]
        std_input[model_var] = std_value
    return std_input

# 计算交互项
def calculate_interactions(std_input):
    interactions = {
        'x6x9': std_input['x6'] * std_input['x9'],
        'x5x9': std_input['x5'] * std_input['x9'],
        'x1x9': std_input['x1'] * std_input['x9'],
        'x1x2': std_input['x1'] * std_input['x2'],
        'x6x7': std_input['x6'] * std_input['x7'],
        'x2x9': std_input['x2'] * std_input['x9'],
        'x3x4': std_input['x3'] * std_input['x4'],
        'x3x5': std_input['x3'] * std_input['x5']
    }
    return interactions

# 执行Prais-Winsten预测（修正后）
def predict_prais(input_values):
    std_input = standardize_input(input_values)
    interactions = calculate_interactions(std_input)
    
    # 合并一次项和交互项
    all_terms = {**std_input, **interactions}
    
    # 计算线性组合
    linear_combination = sum(
        all_terms[term] * coefficients[term] 
        for term in coefficients if term in all_terms
    )
    
    # 还原预测值
    base_prediction = linear_combination * sigma_y + mu_y
    
    # 获取因变量滞后值
    y_lag1 = Decimal(input_values['y_interpL1'])
    
    # 修改后的修正项: 0.267*mu_y + 0.733*y_lag1
    correction_term = Decimal('0.267') * mu_y + Decimal('0.733') * y_lag1
    
    # 最终预测值
    final_prediction = base_prediction + correction_term
    return final_prediction

# GUI界面类
class PredictionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("金融异常检测预测系统")
        self.root.geometry("800x600")
        
        self.entries = {}
        self.prediction = None
        
        # 创建主框架
        main_frame = ttk.Frame(root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建输入区域
        input_frame = ttk.LabelFrame(main_frame, text="输入变量值（带*为必填）", padding="10")
        input_frame.pack(fill=tk.X, pady=10)
        
        # 输入变量列表（按顺序排列）
        input_vars = [
            'mbishu_interp', 'mamiyue_interp', 'mjiage_interp',
            'mvixyue_interp', 'mtps_interp', 'd_mshizhi',
            'd_mtvl', 'y_interpL1'
        ]
        
        # 创建输入表单
        row = 0
        for var in input_vars:
            col = 0 if row % 2 == 0 else 2
            ttk.Label(input_frame, text=f"{variable_desc[var]}* ({var}):", 
                     font=('SimHei', 10)).grid(
                row=row, column=col, sticky=tk.W, pady=5, padx=10
            )
            entry = ttk.Entry(input_frame, width=25, font=('SimHei', 10))
            entry.grid(row=row, column=col+1, pady=5, padx=10)
            self.entries[var] = entry
            row += 1
        
        # 执行预测按钮
        btn_frame = ttk.Frame(input_frame)
        btn_frame.grid(row=row, column=0, columnspan=4, pady=15)
        ttk.Button(btn_frame, text="执行预测", command=self.perform_prediction,
                  style='Accent.TButton', width=15).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="重置", command=self.reset_form,
                  width=10).pack(side=tk.LEFT, padx=10)
        
        # 创建结果区域
        self.create_result_frame(main_frame)
        self.setup_styles()
    
    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Accent.TButton', font=('SimHei', 11, 'bold'), foreground='white', background='#2E8B57')
        style.configure('ResultTitle.TLabel', font=('SimHei', 14, 'bold'))
        style.configure('ResultValue.TLabel', font=('SimHei', 12, 'bold'), foreground='green')
        style.configure('Warning.TLabel', font=('SimHei', 12, 'bold'), foreground='red')
        style.configure('Normal.TLabel', font=('SimHei', 10))
    
    def create_result_frame(self, parent):
        result_frame = ttk.LabelFrame(parent, text="检测结果", padding="20")
        result_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # 预测结果标题
        ttk.Label(result_frame, text="综合预测结果:", style='ResultTitle.TLabel').grid(
            row=0, column=0, sticky=tk.W, pady=5
        )
        
        # 结果状态
        self.status_label = ttk.Label(result_frame, text="", style='ResultValue.TLabel')
        self.status_label.grid(row=0, column=1, sticky=tk.W, padx=20)
        
        # 预测值显示
        ttk.Label(result_frame, text="Prais-Winsten模型输出值:", style='Normal.TLabel').grid(
            row=1, column=0, sticky=tk.W, pady=5
        )
        self.prediction_value = ttk.Label(result_frame, text="", style='Normal.TLabel')
        self.prediction_value.grid(row=1, column=1, sticky=tk.W)
        
        # 滞后值显示
        ttk.Label(result_frame, text="因变量滞后值(yₜ₋₁):", style='Normal.TLabel').grid(
            row=2, column=0, sticky=tk.W, pady=5
        )
        self.lag_value = ttk.Label(result_frame, text="", style='Normal.TLabel')
        self.lag_value.grid(row=2, column=1, sticky=tk.W)
        
        # 修正项显示
        ttk.Label(result_frame, text="修正项(0.73×标准化滞后值):", style='Normal.TLabel').grid(
            row=3, column=0, sticky=tk.W, pady=5
        )
        self.correction_value = ttk.Label(result_frame, text="", style='Normal.TLabel')
        self.correction_value.grid(row=3, column=1, sticky=tk.W)
        
        # 状态判断依据
        ttk.Label(result_frame, text="判断依据:", style='ResultTitle.TLabel').grid(
            row=4, column=0, sticky=tk.W, pady=15
        )
        self.reason_display = tk.Text(result_frame, wrap=tk.WORD, height=5, width=60,
                                     font=('SimHei', 10), bd=1, relief='solid')
        self.reason_display.grid(row=4, column=1, sticky=tk.W, pady=5, padx=10)
    
    def perform_prediction(self):
        input_values = {}
        for var, entry in self.entries.items():
            try:
                value = Decimal(entry.get())
                input_values[var] = value
            except ValueError:
                messagebox.showerror("输入错误", f"请输入正确的数值：{variable_desc[var]}")
                return
        
        # 检查必填变量
        for var in ['y_interpL1']:  # 因变量滞后值为强制输入
            if not input_values.get(var):
                messagebox.showerror("输入错误", f"请输入{variable_desc[var]}")
                return
        
        try:
            # 获取基础预测值和修正项
            base_prediction = predict_prais(input_values)
            y_lag1 = input_values['y_interpL1']
            
            # 计算修正项
            correction = CORRECTION_FACTOR * (y_lag1 - mu_y) / sigma_y
            
            # 状态判断
            prais_status = "正常" if (LOWER_BOUND <= base_prediction <= UPPER_BOUND) else "异常"
            lag_status = "正常" if (LOWER_BOUND <= y_lag1 <= UPPER_BOUND) else "异常"
            
            # 综合决策逻辑
            if prais_status == "正常" and lag_status == "正常":
                final_status = "正常"
                reason = "Prais-Winsten模型输出值与因变量滞后值均在正常范围内"
                color = 'green'
            elif prais_status == "异常" and lag_status == "异常":
                final_status = "双重异常"
                reason = "Prais模型输出值与因变量滞后值均超出正常范围，存在显著流动性风险"
                color = 'red'
            elif prais_status == "异常":
                final_status = "模型预测异常"
                reason = "Prais-Winsten模型输出值超出正常范围，可能存在流动性波动"
                color = 'orange'
            else:  # lag_status异常
                final_status = "滞后值异常"
                reason = "因变量滞后值超出正常范围，显示历史数据存在异常波动"
                color = 'orange'
            
            # 更新界面显示
            self.status_label.config(text=final_status, style=f'{final_status}.TLabel')
            self.prediction_value.config(text=f"{base_prediction:.6f} ({prais_status})")
            self.lag_value.config(text=f"{y_lag1:.6f} ({lag_status})")
            self.correction_value.config(text=f"{correction:.6f}")
            self.reason_display.delete(1.0, tk.END)
            self.reason_display.insert(tk.END, reason)
            
        except Exception as e:
            messagebox.showerror("计算错误", f"预测过程中发生错误：{str(e)}")
            return
    
    def reset_form(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.status_label.config(text="")
        self.prediction_value.config(text="")
        self.lag_value.config(text="")
        self.correction_value.config(text="")
        self.reason_display.delete(1.0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    # 添加异常状态样式
    style = ttk.Style()
    style.configure('正常.TLabel', foreground='green')
    style.configure('异常.TLabel', foreground='red')
    style.configure('双重异常.TLabel', foreground='red', font=('SimHei', 12, 'bold'))
    app = PredictionApp(root)
    root.mainloop()